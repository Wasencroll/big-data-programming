/**
* University of Skövde | Big data programming | Assignment 2: Spark
* 
* HOW TO DEPLOY:
* http://spark.apache.org/docs/latest/quick-start.html#self-contained-applications
*/

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

/** SQL FUNCTIONS FOR DATA FRAMES e.g. avg("..."), orderBy(desc("...")).
* http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.functions$ */
import org.apache.spark.sql.functions._

/** Import for creating and writing into files. 
* Not needed if you're writing with the RDD's or data frame's built-in writers. */
import java.io._


object Comments {
	def main(arg: Array[String]) = {
		/** SPARK CONFIGURATION
		* http://spark.apache.org/docs/latest/configuration.html
		*
		* The app name is shown in the Spark web UI: localhost:4040
		 */
		val conf = new SparkConf().setAppName("Reddit comments")


		/** Create Spark context in case you're working with RDDs. */
		val sc = new SparkContext(conf)
		// You can silence the console output a bit...
		sc.setLogLevel("WARN")


		/** Create Spark session for working with data frames. */
		val spark = SparkSession.builder().getOrCreate()
		// Needed import if you want to use $ for columns e.g. $"author"...
		import spark.implicits._



		// PATH TO DATA. Check if it is correct.
		val dataPath = "/media/elio/Data/datasets/reddit_data/2010"
		// PATH TO STOP WORDS FILE.
		val swPath = "res/stopwords.txt"

		// ======================== YOUR CODE =============================
		// Use "Output results" section below to save your results.
		// Remember to use data frames.
		val data = spark.read.parquet(dataPath)

		val df = data.select(
			month(from_unixtime($"created_utc")).as("month"),
			weekofyear(from_unixtime($"created_utc")).as("week"), 
			hour(from_unixtime($"created_utc")).as("hour"),
			$"subreddit", 
			$"body", 
			$"ups")

		// df.persist

		// val hours = df
		df
		.groupBy("hour")
		.count
		.orderBy(desc("count"))
		.write
		.csv("results/commentsperhour.csv")
		// .collect

		// val avgsub = df
		df
		.groupBy("subreddit")
		.agg(avg("ups").as("upavg"))
		.orderBy(desc("upavg"))
		.write
		.csv("results/avgsubreddit.csv")
		// .collect

		// val ups = df
		df
		.orderBy($"week", desc("ups"))
		.groupBy("week")
		.agg(first("subreddit"), first("ups"), first("body"))
		.write
		.csv("results/highestups.csv")
		// .collect
		
		val stopwords = sc.textFile(swPath).collect
		// val words = df
		df
		.select("body")
		.flatMap(r => r(0).toString.split(" "))
		.filter(w => stopwords.forall(!_.equalsIgnorCase(w)))
		.groupBy("value")
		.count
		.orderBy(desc("count"))
		.write
		.csv("results/frequentwords.csv")
		// .collect

		// ======================= Output results =========================
		// --- Question 1: Number comments per hour.
		// val commentsperhour = new PrintWriter(new File("results/commentsperhour.csv" ))
		// commentsperhour.println("hour;count")
		// // Print answer to file here with the following format: 
		// // 		<hour>;<count>				E.g.: 22;845
		// hours.foreach{ r =>
		// 	val hour = r(0)
		// 	val count = r(1)
		// 	commentsperhour.println(s"$hour;$count")
		// }
		// commentsperhour.close


		// --- Question 2: Average ups per subreddit.
		// val avgperreddit = new PrintWriter(new File("results/wordsperweek.csv" ))
		// avgperreddit.println("day;average")
		// // Print answer to file here with the following format: 
		// // 		<subreddit>;<average>		E.g.: AskReddit;10.4894
		// avgsub.foreach{ r =>
		// 	val subreddit = r(0)
		// 	val average = r(1)
		// 	avgperreddit.println(s"$subreddit;$average")
		// }
		// avgperreddit.close


		// --- Question 3: Highest ups per week of year.
		// val highestups = new PrintWriter(new File("results/highestups.csv" ))
		// highestups.println("week;subreddit;ups;comment")
		// ups.foreach{ r =>
		// 	val week = r(0)
		// 	val subreddit = r(1)
		// 	val up = r(2)
		// 	val body = r(3)
		// 	highestups.println(s"$week;$subreddit;$up;$body")
		// }
		// // Print answer to file here with the following format: 
		// // 		<month>;<ups>;<comment>		E.g.: 10;9564;Some very popular comment
		// highestups.close


		// // --- Question 3: Average words per day of the week.
		// val wordsperweek = new PrintWriter(new File("results/wordsperweek.csv" ))
		// wordsperweek.println("day;average")
		// // Print answer to file here with the following format: 
		// // 		<day of week>;<average>		E.g.: 5;10.4894
		// wordsperweek.close

		
		// --- Question 4: Most frequent (non-stop) words.
		// val frequentwords = new PrintWriter(new File("results/frequentwords.csv" ))
		// frequentwords.println("word;count")
		// // 		<word>;<count>				E.g.: Obama;756
		// words.foreach{ r =>
		// 	val w = r(0)
		// 	val count = r(1)
		// 	frequentwords.println(s"$w;$count")
		// }
		// frequentwords.close
		

		sc.stop
	}
}